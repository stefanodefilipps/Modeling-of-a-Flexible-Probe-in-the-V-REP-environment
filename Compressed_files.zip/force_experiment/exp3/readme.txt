I apply a building force instead of an impulse all of a sudden.
I apply the force to 32 link F = [0,0.02,-0.01]
Up to the 150 time instant i let the force grow then it decreases to 0

lambda_fE=[10e-4 4e-6 0];
