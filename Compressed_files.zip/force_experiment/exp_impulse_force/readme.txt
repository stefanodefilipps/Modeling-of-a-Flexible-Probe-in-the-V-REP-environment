I used SPRING DAMPER control mode because more spring behaviour
I applied force to 32 link F = [-0.01,-0.03,0]
applied maximum target velocity 100
damping factors lambda_fE=[20e-4 4e-6 0 0 0 0];

Oscillations because it is never in right equilibrium but profiles at least are coerent

before estimating the forces I filtered the torques data and joints data and I actually get better results
