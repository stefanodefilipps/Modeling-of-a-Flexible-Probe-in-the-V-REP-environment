i made translate a cube against the catheter in order to apply a force
link interested were 7 8 9 10 25 26 
lambda_fE=[8e-5 4e-6 0 8e-5 4e-6 0 8e-5 4e-6 0 8e-5 4e-6 0 8e-5 4e-6 0 8e-5 4e-6 0];

SPRING DAMPER SYSTEM


