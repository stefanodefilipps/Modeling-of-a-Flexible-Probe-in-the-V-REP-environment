i made translate a cube against the catheter in order to apply a force
link interested were 27 28 29 
lambda_fE=[6e-3 4e-6 0 6e-3 4e-6 0 6e-3 4e-6 0];

SPRING DAMPER SYSTEM


